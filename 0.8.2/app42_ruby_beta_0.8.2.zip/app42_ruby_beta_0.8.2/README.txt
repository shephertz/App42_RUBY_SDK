//App42 RUBY SDK

1. UnZip the downloaded file
2. This will contain App42_RUBY_SDK_x.x.x.gem ,Docs, Sample Folder, Ruby_Cloud_API_Guide.pdf and README.txt
3. Docs folder contains API docs
4. Sample folder contains RUBY sample project for using App42 RUBY SDK.
5. Please visit http://api.shephertz.com/cloudapidocs/index.php for detail documentaion and tutorials.
