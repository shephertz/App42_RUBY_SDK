api = App42::ServiceAPI.new(API_KEY,SECRET_KEY)
$user_obj = api.buildUserService
 
