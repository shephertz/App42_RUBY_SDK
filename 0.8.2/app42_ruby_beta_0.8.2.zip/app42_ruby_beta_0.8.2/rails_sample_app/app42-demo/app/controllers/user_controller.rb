class UserController < ApplicationController
  def create
    user = $user_obj.create_user(params[:userName], params[:password], params[:email])  
	redirect_to user_index_path
  end

  def index
  	@users = $user_obj.get_all_users
  end
end
