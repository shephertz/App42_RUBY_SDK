//App42 RUBY SDK

1. UnZip the downloaded file.
2. This will contain App42_RUBY_SDK_0.7.0.gem ,Docs, Sample Folder and README.txt.
3. Docs folder contains API docs.
4. Sample folder contains RUBY sample project for using App42 RUBY API's.
5. Please visit http://apps.shephertz.com/CloudAPI/cloudapidocs/index.php for detail documentaion and tutorials.
